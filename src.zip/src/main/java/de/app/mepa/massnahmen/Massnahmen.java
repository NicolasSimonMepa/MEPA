package de.app.mepa.massnahmen;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import de.app.mepa.mepa.R;

public class Massnahmen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_massnahmen);
    }

}
