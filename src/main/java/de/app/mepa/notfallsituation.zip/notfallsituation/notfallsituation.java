package de.app.mepa.notfallsituation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import de.app.mepa.mepa.R;

public class notfallsituation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notfallsituation);
    }
}
