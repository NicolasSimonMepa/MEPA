package de.app.mepa.pers_daten;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import de.app.mepa.mepa.R;

public class Pers_daten extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pers_daten);
    }
}
