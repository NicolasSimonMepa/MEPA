//Zuletzt geändert von Vivien Stumpe, 10.04.16
package de.app.mepa.upload;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import de.app.mepa.mepa.R;

public class Upload extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
    }
}
